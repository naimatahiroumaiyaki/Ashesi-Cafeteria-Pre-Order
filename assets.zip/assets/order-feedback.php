<?php
session_start();
require_once('../connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $orderId = $_POST['order_id'];
    $rating = $_POST['rating'];
    $message = $_POST['message'];
    
    $stmt = $conn->prepare("INSERT INTO feedback (user_id, order_id, rating, message, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("iiis", $userId, $orderId, $rating, $message);
    
    $response = array();
    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Thank you for your feedback!";
    } else {
        $response['success'] = false;
        $response['message'] = "Error submitting feedback. Please try again.";
    }
    
    echo json_encode($response);
    exit();
}
?>