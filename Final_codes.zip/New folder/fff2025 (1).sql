-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2025 at 11:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fff2025`
--

-- --------------------------------------------------------

--
-- Table structure for table `cafeterias`
--

CREATE TABLE `cafeterias` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `login_password_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cafeterias`
--

INSERT INTO `cafeterias` (`id`, `name`, `login_password_hash`) VALUES
(2027123, 'Akorno', '$2y$10$LQ4kNcv9pjhGQg6kekJdzudhmmm2ynpv5353MV/DxlZyIIZTmFEFq'),
(2027456, 'Hallmark', '$2y$10$GZkW4ymr0h2zZZxxWS4k5ePi3yv6D9iBSmg11BoJVOfk2SwfvehmS'),
(2027789, 'Munchies', '$2y$10$79dw5Q8MVrbfzvZVA1FohuvOBP6SdlWWgcmJuj8x8erl4fqsHvjhi');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `cafeteria_id` int(11) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cafeteria_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cafeteria_id` int(11) DEFAULT NULL,
  `order_items` text DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `order_type` varchar(20) DEFAULT NULL,
  `payment_method` varchar(20) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  `pin` varchar(50) DEFAULT NULL,
  `momo_reference` varchar(100) DEFAULT NULL,
  `delivery_location` varchar(255) DEFAULT NULL,
  `delivery_instructions` text DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `cafeteria_id`, `order_items`, `total_amount`, `order_type`, `payment_method`, `student_id`, `pin`, `momo_reference`, `delivery_location`, `delivery_instructions`, `phone_number`, `status`, `created_at`) VALUES
(57, 2027461, 2027456, '[{\"id\":36,\"name\":\"Club Sandwich\",\"price\":18,\"quantity\":1}]', 18.00, 'dine-in', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-11-29 20:16:00'),
(58, 2027461, 2027123, '[{\"id\":1,\"name\":\"Kenkey\",\"price\":20,\"quantity\":3}]', 60.00, 'delivery', 'mealplan', 'fati@ashesi.edu.gh', 'fati123', NULL, 'On campus-hostel 2d', '', NULL, 'received', '2025-11-29 20:48:01'),
(59, 7, 2027789, '[{\"id\":60,\"name\":\"Milkshake\",\"price\":18,\"quantity\":1}]', 18.00, 'dine-in', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-11-29 20:57:15'),
(60, 7, 2027123, '[{\"id\":2,\"name\":\"Chawarma\",\"price\":15,\"quantity\":1}]', 15.00, 'dine-in', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-11-29 21:04:52'),
(61, 7, 2027123, '[{\"id\":3,\"name\":\"Grilled Chicken\",\"price\":25,\"quantity\":1}]', 25.00, 'dine-in', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-11-29 21:06:01'),
(62, 2027462, 2027789, '[{\"id\":61,\"name\":\"Ice Tea\",\"price\":12,\"quantity\":1},{\"id\":62,\"name\":\"Fried Yam\",\"price\":20,\"quantity\":2},{\"id\":64,\"name\":\"Pack\",\"price\":6,\"quantity\":1}]', 58.00, 'takeout', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-11-29 21:50:20'),
(63, 2027463, 2027123, '[{\"id\":11,\"name\":\"Boiled Yam\",\"price\":30,\"quantity\":1}]', 30.00, 'dine-in', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-11-30 18:42:58'),
(64, 2027461, 2027456, '[{\"id\":36,\"name\":\"Club Sandwich\",\"price\":18,\"quantity\":1},{\"id\":54,\"name\":\"Paper Bag\",\"price\":3,\"quantity\":1},{\"id\":55,\"name\":\"Chicken Sandwich\",\"price\":38,\"quantity\":1}]', 59.00, 'dine-in', 'mealplan', '30252027', '3321', NULL, NULL, NULL, NULL, 'received', '2025-11-30 20:53:59'),
(65, 2027470, 2027456, '[{\"id\":37,\"name\":\"breakfast Pack\",\"price\":15,\"quantity\":1},{\"id\":52,\"name\":\"Mango juice\",\"price\":15,\"quantity\":1}]', 30.00, 'dine-in', 'momo', NULL, NULL, '', NULL, NULL, NULL, 'received', '2025-11-30 21:07:03'),
(66, 2027471, 2027456, '[{\"id\":37,\"name\":\"breakfast Pack\",\"price\":15,\"quantity\":1},{\"id\":40,\"name\":\"Black Coffee\",\"price\":10,\"quantity\":1}]', 25.00, 'takeout', 'mealplan', '30252027', '2345', NULL, NULL, NULL, NULL, 'received', '2025-11-30 21:14:55'),
(67, 2027471, 2027123, '[{\"id\":1,\"name\":\"Kenkey\",\"price\":20,\"quantity\":1},{\"id\":23,\"name\":\"Waakye\",\"price\":38,\"quantity\":1}]', 58.00, 'dine-in', 'mealplan', '30252027', '', NULL, NULL, NULL, NULL, 'received', '2025-11-30 21:17:31'),
(68, 2027471, 2027789, '[{\"id\":57,\"name\":\"Waakye\",\"price\":22,\"quantity\":1}]', 22.00, 'delivery', 'cash', NULL, NULL, NULL, '', '', NULL, 'received', '2025-11-30 21:18:36'),
(69, 2027472, 2027789, '[{\"id\":57,\"name\":\"Waakye\",\"price\":22,\"quantity\":1},{\"id\":65,\"name\":\"Paper Bag\",\"price\":3,\"quantity\":1}]', 25.00, 'delivery', 'cash', NULL, NULL, NULL, 'On campus-hostel 2d', 'roomG10', NULL, 'received', '2025-11-30 21:25:05'),
(70, 2027473, 2027456, '[{\"id\":40,\"name\":\"Black Coffee\",\"price\":10,\"quantity\":2},{\"id\":54,\"name\":\"Paper Bag\",\"price\":3,\"quantity\":1}]', 23.00, 'delivery', 'cash', NULL, NULL, NULL, 'On campus-hostel 2d', 'RoomG13', NULL, 'received', '2025-11-30 21:44:07'),
(71, 2027475, 2027456, '[{\"id\":36,\"name\":\"Club Sandwich\",\"price\":18,\"quantity\":2}]', 36.00, 'delivery', 'cash', NULL, NULL, NULL, 'On campus-hostel 2d', 'Room10', NULL, 'received', '2025-12-01 22:54:44'),
(72, 1, 2027456, '[{\"id\":36,\"name\":\"Club Sandwich\",\"price\":18,\"quantity\":1}]', 18.00, 'dine-in', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-12-03 19:51:59'),
(73, 1, 2027789, '[{\"id\":65,\"name\":\"Paper Bag\",\"price\":3,\"quantity\":1}]', 3.00, 'dine-in', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-12-03 20:14:17'),
(74, 1, 2027123, '[{\"id\":2,\"name\":\"Chawarma\",\"price\":15,\"quantity\":1}]', 15.00, 'takeout', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-12-03 20:36:58'),
(75, 2027464, 2027123, '[{\"id\":1,\"name\":\"Kenkey\",\"price\":20,\"quantity\":1},{\"id\":2,\"name\":\"Chawarma\",\"price\":15,\"quantity\":1},{\"id\":23,\"name\":\"Waakye\",\"price\":38,\"quantity\":1}]', 73.00, 'takeout', 'cash', NULL, NULL, NULL, NULL, NULL, NULL, 'received', '2025-12-03 21:00:50'),
(76, 2027477, 2027456, '[{\"id\":35,\"name\":\"Pasta Bolognese\",\"price\":25,\"quantity\":1},{\"id\":36,\"name\":\"Club Sandwich\",\"price\":18,\"quantity\":1},{\"id\":39,\"name\":\"Pineaple juice\",\"price\":15,\"quantity\":1}]', 58.00, 'delivery', 'mealplan', '15612027', '15612027', NULL, 'hostel-2c', 'room I8', NULL, 'received', '2025-12-03 21:03:14'),
(77, 2027469, 2027123, '[{\"id\":6,\"name\":\"Small Water\",\"price\":3,\"quantity\":1}]', 3.00, 'takeout', 'cash', NULL, NULL, NULL, NULL, NULL, '', 'received', '2025-12-03 21:30:04'),
(78, 2027469, 2027456, '[{\"id\":37,\"name\":\"breakfast Pack\",\"price\":15,\"quantity\":1}]', 15.00, 'takeout', 'cash', NULL, NULL, NULL, NULL, NULL, '', 'received', '2025-12-03 21:39:48'),
(79, 2027477, 2027123, '[{\"id\":8,\"name\":\"Banku\",\"price\":38,\"quantity\":1}]', 38.00, 'dine-in', 'cash', NULL, NULL, NULL, NULL, NULL, '', 'received', '2025-12-03 21:40:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','staff','admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `cafeteria_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `role`, `created_at`, `cafeteria_id`) VALUES
(1, 'nana', 'nana@ashesi.edu.gh', '$2y$10$AKbpSLn3Di85UU/TgO.VvebKtwfox5bw8ZIW99j0vEty4Cznt7Fgi', 'user', '2025-11-07 12:55:40', NULL),
(2, 'martha', 'martha@ashesi', '$2y$10$mtDrfjtEaU3iHFK2OaurGebd6q.LMDqFOF/rkxEADnrH6M3HU/5We', 'user', '2025-11-12 08:00:27', NULL),
(7, 'naima', 'naima@ashesi', '', 'staff', '2025-11-13 15:59:43', 2027789),
(2027461, 'Fati', 'fati@ashesi.edu.gh', '$2y$10$jGlrlXQZVO3TxAkD9QsKLOZGHEyR6L72iZTGfhYt4GC3YbBeBXLeC', 'user', '2025-11-20 15:18:53', NULL),
(2027462, 'Emmanuel', 'ema@ashesi', '$2y$10$3.GIdQi3YCpsHUzuEKCKG.IQ5/3u2in.CclnYZRe2lqBtQ6wonmMS', 'user', '2025-11-29 21:49:22', NULL),
(2027463, 'debora', 'debora@ashesi', '$2y$10$oFl7qC0kJnQcyOto9skeJuN1H98HkqN6K8jCmqtzBIaLMXr/7DM5W', 'user', '2025-11-30 18:42:03', NULL),
(2027464, 'Esther', 'Esther@ashesi.edu.gh', '', 'staff', '2025-11-30 18:50:19', 2027123),
(2027468, 'Debora', 'debora@gmail.com', '', 'staff', '2025-11-30 18:54:14', 2027123),
(2027469, 'Mariem', 'mariem@gmail.com', '', 'staff', '2025-11-30 18:57:14', 2027456),
(2027470, 'Farida', 'farida@ashesi.edu.gh', '$2y$10$LMnCB7rTX8AssG6/4kSJxuiNT6qdA0pAHyFUVBDMXaukzsZmtoX1K', 'user', '2025-11-30 21:05:03', NULL),
(2027471, 'Ben', 'ben@ashesi.edu.gh', '$2y$10$UB97InmZsfTr4dUOqOGFF.nwnkkp6nIdUjqfSVpBf8NtfYMJ7qmyu', 'user', '2025-11-30 21:12:17', NULL),
(2027472, 'Debo', 'debo@ashesi.edu.gh', '$2y$10$QPLuW6si3oK5kYL//P6jm.EyeWxQKmS4hVXJDrvscD5HZIhAhov8i', 'user', '2025-11-30 21:22:39', NULL),
(2027473, 'Barbie', 'barbi@ashesi.edu.gh', '$2y$10$ld77dHMwmkVOr7f4zLGGAuhsE1ZXqNmYARTjnwYR3iPqVua.5Fr6q', 'user', '2025-11-30 21:40:36', NULL),
(2027474, 'Fatiha', 'fatiha@gmail.com', '$2y$10$OSt1S.MoyGG4L1QfvDhpW.91B443B6do58pys7M8xLlFlGx.Lo.dO', 'user', '2025-12-01 22:43:32', NULL),
(2027475, 'Nana', 'nan@gmail.com', '$2y$10$FrMlg7u.5iKziHccmXIjk.2pyZWUpJyGu9zgiBKDkYVMBWeQtoY1S', 'user', '2025-12-01 22:49:09', NULL),
(2027476, 'Aicha', 'aicha@ashesi.edu.gh', '$2y$10$qbjo23vHd18YxqbEa2lUJ.qe3fv...O22yUT/QptizGLwEC5z0qZS', 'user', '2025-12-03 09:53:59', NULL),
(2027477, 'John', 'john@ashesi.edu.gh', '$2y$10$IZUXEJHk3g5SALk4V8JxFe8d/Tkc.Om2KL/TMpGs.3iy0JhQKjMR2', 'user', '2025-12-03 21:01:40', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cafeterias`
--
ALTER TABLE `cafeterias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cafeteria_id` (`cafeteria_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user` (`user_id`),
  ADD KEY `fk_orders_cafeteria` (`cafeteria_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_cafeteria` (`cafeteria_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cafeterias`
--
ALTER TABLE `cafeterias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2027790;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2027478;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`cafeteria_id`) REFERENCES `cafeterias` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_cafeteria` FOREIGN KEY (`cafeteria_id`) REFERENCES `cafeterias` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_cafeteria` FOREIGN KEY (`cafeteria_id`) REFERENCES `cafeterias` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
