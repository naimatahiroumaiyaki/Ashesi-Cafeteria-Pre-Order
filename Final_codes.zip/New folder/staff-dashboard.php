<?php
session_start();
include('connect.php');

// Only staff can access this
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff') {
    header("Location: login.php");
    exit();
}

$cafeteria_id = $_SESSION['cafeteria_id'];
$cafeteria_name = $_SESSION['cafeteria_name']; 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Staff Dashboard</title>

    <!-- FontAwesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body { font-family: Arial; padding: 20px; }

        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #eee; }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f4f4f4;
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .logout-btn {
            background: #d9534f;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .items-table {
            border: 1px solid #aaa;
            width: 100%;
            background: #f9f9f9;
        }
        .items-table th {
            background: #ddd;
        }
    </style>
</head>

<body>

<header class="dashboard-header">
    <div class="header-left">
        <h1>Welcome, <?php echo htmlspecialchars($cafeteria_name); ?> Staff!</h1>
    </div>

    <a href="<?php echo dirname($_SERVER['PHP_SELF']); ?>/logout.php" 
       class="logout-btn"
       onclick="return confirm('Are you sure you want to logout?')">
        Logout
    </a>
</header>


<h2>Orders</h2>

<table>
<tr>
    <th>Order ID</th>
    <th>User</th>
    <th>Order Type</th>
    <th>Payment Method</th>
    <th>Student ID</th>
    <th>MoMo Reference</th>
    <th>Delivery Location</th>
    <th>Delivery Instructions</th>
    <th>Phone Number</th>
    <th>Items</th>
</tr>

<?php
$sql = "SELECT orders.*, users.name AS user_name 
        FROM orders 
        JOIN users ON orders.user_id = users.id 
        WHERE orders.cafeteria_id = ? 
        ORDER BY orders.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cafeteria_id);
$stmt->execute();
$result = $stmt->get_result();

while ($order = $result->fetch_assoc()) {

    $items = json_decode($order['order_items'], true);

    echo "<tr>";
    echo "<td>{$order['id']}</td>";
    echo "<td>{$order['user_name']}</td>";
    echo "<td>{$order['order_type']}</td>";
    echo "<td>{$order['payment_method']}</td>";
    echo "<td>" . ($order['student_id'] ?: '-') . "</td>";
    echo "<td>" . ($order['momo_reference'] ?: '-') . "</td>";
    echo "<td>" . ($order['delivery_location'] ?: '-') . "</td>";
    echo "<td>" . ($order['delivery_instructions'] ?: '-') . "</td>";
    echo "<td>" . ($order['phone_number'] ?: '-') . "</td>";

    echo "<td>";
    echo "<table class='items-table'>";
    echo "<tr>
            <th>Item ID</th>
            <th>Name</th>
            <th>Qty</th>
            <th>Price</th>
          </tr>";

    foreach ($items as $item) {
        echo "<tr>
                <td>{$item['id']}</td>
                <td>{$item['name']}</td>
                <td>{$item['quantity']}</td>
                <td>{$item['price']}</td>
              </tr>";
    }

    echo "</table>";
    echo "</td>";

    echo "</tr>";
}
?>

</table>

</body>
</html>
