
<?php echo password_hash("Munchies2027789", PASSWORD_DEFAULT); ?>