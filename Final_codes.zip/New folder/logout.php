<?php
session_start();

session_unset();
session_destroy();

// ALWAYS redirect correctly from any folder
header("Location: register.php");
exit();
?>
