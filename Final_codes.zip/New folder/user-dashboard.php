<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
include 'connect.php';

// Get user info
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Dashboard — Ashesi Cafeteria</title>
    <link rel="stylesheet" href="user-dashboard.css">
</head>
<body>

<header class="dashboard-header">
    <div class="header-left">
        <h1>Welcome, <?php echo htmlspecialchars($user_name); ?>!</h1>
    </div>
    <a href="<?php echo dirname($_SERVER['PHP_SELF']); ?>/logout.php" 
       class="logout-btn"
       onclick="return confirm('Are you sure you want to logout?')">
        Logout
    </a>
</header>

<main class="dashboard-container">

    <!-- Cafeteria selection -->
    <section class="cafeteria-section">
        <h2>Select a Restaurant</h2>
        <select id="cafeteriaSelect">
            <option value="">-- Choose a Restaurant --</option>
            <option value="akorno">Akorno</option>
            <option value="hallmark">Hallmark</option>
            <option value="munchies">Munchies</option>
        </select>
    </section>

    <!-- Menu -->
    <section class="menu-section">
        <div class="section-header">
            <h2>Menu</h2>

        </div>

        <div class="menu-categories">
            <button class="category-btn active" data-category="all">All</button>
            <button class="category-btn" data-category="breakfast">Breakfast</button>
            <button class="category-btn" data-category="lunch">Lunch</button>
            <button class="category-btn" data-category="dinner">Dinner</button>
            <button class="category-btn" data-category="snack">Snack</button>
            <button class="category-btn" data-category="drinks">Drinks</button>
            <button class="category-btn" data-category="singles">Singles</button>
            <button class="category-btn" data-category="packs">Packs</button>
        </div>

        <div class="menu-search">
            <input type="search" placeholder="Search menu items…" id="menuSearch">
        </div>

        <div id="menuList" class="menu-container">
            <div class="empty-state">
                <p>Please select a restaurant to view its menu.</p>
            </div>
        </div>
        <div class="cart-summary" style="background: #942121ff; color: white; padding: 1rem 2rem; border-radius: 12px; text-align: right; font-size: 1.25rem; margin-top: 1.5rem; display: block;">
            Total amount: <strong>¢<span id="orderTotal">0.00</span></strong>
        </div>
    </section>

    <!-- Order Form -->
    <div class="order-form-section">
        <h2>Place Your Order</h2>
        
        <form id="orderForm">
            <div class="form-row">
                <div class="form-group">
                    <label for="orderType">Order Type:</label>
                    <select id="orderType" required>
                        <option value="">-- Select Order Type --</option>
                        <option value="delivery">Delivery</option>
                        <option value="dine-in">Dine In</option>
                        <option value="takeout">Take Out</option>
                        
                    </select>
                </div>

                <div class="form-group">
                    <label for="paymentMethod">Payment Method:</label>
                    <select id="paymentMethod" required>
                        <option value="">-- Select Payment Method --</option>
                        <option value="mealplan">Meal Plan</option>
                        <option value="cash">Cash</option>
                        <option value="momo">Mobile Money</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="phoneNumber">Your Phone Number (for order updates)</label>
                <input type="tel" id="phoneNumber" placeholder="e.g., 0551234567" required>
                <small style="color: #666; font-size: 0.875rem;">We'll contact you to update you about your order</small>
            </div>

            <!-- Meal Plan Payment -->
            <div id="mealPlanFields" class="hidden payment-fields">
                <div class="form-group"><label for="studentId">Student ID:</label><input type="text" id="studentId"></div>
                <div class="form-group"><label for="mealPlanPin">PIN:</label><input type="password" id="mealPlanPin"></div>
            </div>

            <!-- MoMo Payment -->
            <div id="momoFields" class="hidden payment-fields">
                <div class="form-group"><label>Cafeteria MoMo Number:</label><div id="momoNumber" class="momo-display"></div></div>
                <p class="momo-instructions">Send the total amount to the number above and enter the reference below.</p>
                <div class="form-group"><label for="momoReference">Reference:</label><input type="text" id="momoReference"></div>
            </div>

            <!-- Delivery fields -->
            <div id="deliveryFields" class="hidden delivery-fields">
                <div class="form-group"><label for="deliveryLocation">Location:</label><input type="text" id="deliveryLocation"></div>
                <div class="form-group"><label for="deliveryInstructions">Instructions:</label><textarea id="deliveryInstructions"></textarea></div>
            </div>

            <button type="submit" class="submit-btn">
                Place Order
            </button>
        </form>

        <!-- Order status modal -->
        <div id="orderStatusModal" class="modal hidden">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Order Status</h3>
                    <button class="close-modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div id="orderStatusContent" class="status-message"></div>

                    <div class="order-progress">
                        <div class="progress-step" id="stepReceived">
                            <div class="step-indicator"></div>
                            <div class="step-label">Received</div>
                        </div>
                        <div class="progress-step" id="stepProcessing">
                            <div class="step-indicator"></div>
                            <div class="step-label">Processing</div>
                        </div>
                        <div class="progress-step" id="stepReady">
                            <div class="step-indicator"></div>
                            <div class="step-label">Ready</div>
                        </div>
                        <div class="progress-step" id="stepCompleted">
                            <div class="step-indicator"></div>
                            <div class="step-label">Completed</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>


    <!-- Order details modal -->
    <div id="orderDetailsModal" class="modal hidden">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Order Details</h3>
                <button class="close-modal">&times;</button>
            </div>
            <div class="modal-body">
                <div id="orderDetailsContent"></div>
            </div>
            <div class="modal-footer">
                <button id="cancelOrderBtn" class="danger-btn">Cancel Order</button>
                <button class="close-modal-btn">Close</button>
            </div>
        </div>
    </div>

</main>

<script src="user-dashboard.js"></script>

<script>
    const USER_ID = <?php echo json_encode($user_id); ?>;
    const USER_NAME = <?php echo json_encode($user_name); ?>;

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.add('hidden');
                }
            });
        });

        document.querySelectorAll('.close-modal, .close-modal-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.modal').forEach(modal => {
                    modal.classList.add('hidden');
                });
            });
        });
    });
</script>

</body>
</html>
