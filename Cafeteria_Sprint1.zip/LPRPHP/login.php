<?php
// login.php
session_start();

// Simple authentication (replace with database validation in production)
$valid_credentials = [
    'test@ashesi.edu.gh' => 'password123',
    'mariem.sall@ashesi.edu.gh' => '1234'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Validate Ashesi email
    if (!strpos($email, '@ashesi.edu.gh')) {
        header('Location: login.html?error=invalid_email');
        exit();
    }
    
    // Check credentials (in real app, validate against database)
    if (isset($valid_credentials[$email]) && $valid_credentials[$email] === $password) {
        // Successful login
        $_SESSION['user_email'] = $email;
        $_SESSION['logged_in'] = true;
        
        // Redirect to dashboard
        header('Location: dashboard.html');
        exit();
    } else {
        // Failed login
        header('Location: login.html?error=invalid_credentials');
        exit();
    }
}
?>