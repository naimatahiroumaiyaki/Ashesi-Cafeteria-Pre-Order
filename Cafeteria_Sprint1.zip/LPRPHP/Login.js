document.addEventListener('DOMContentLoaded', function() {
    console.log('Login page loaded'); 
    
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    
    // Testing the credentials:
    const validUsers = {
        'esther@ashesi.edu.gh': 'password123',
        'deborah@ashesi.edu.gh': 'password123',
        'mariem.sall@ashesi.edu.gh': '1234',
        'naima.tahirou@ashesi.edu.gh': '5678'
    };
    
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault(); 
        console.log('Form submitted'); 
        
        const email = emailInput.value.trim();
        const password = passwordInput.value;
        
        console.log('Email:', email); 
        console.log('Password:', password); 
        
        // Checking if the fields are empty:
        if (!email || !password) {
            alert(' Please fill in all fields');
            return;
        }
        
        // Checking  if it is an Ashesi email:
        if (!email.includes('@ashesi.edu.gh')) {
            alert(' Please use your Ashesi University email address (@ashesi.edu.gh)');
            return;
        }
        
        // Checking the credentials:
        if (validUsers[email] && validUsers[email] === password) {
            alert('Login successful! Redirecting to dashboard...');
            console.log('Login successful, redirecting...'); 
            
            //Setting time to redirect:
            setTimeout(function() {
                window.location.href = 'dashboard.html';
            }, 1000);
            
        } else {
            alert('Invalid email or password!\n\nTry these test accounts:\n• esther@ashesi.edu.gh / password123\n• mariem.sall@ashesi.edu.gh / 1234');
        }
    });
    
    // Auto-filling the test credentials for easy testing
    console.log('Test accounts available:'); 
    console.log('esther@ashesi.edu.gh / password123'); 
    console.log('mariem.sall@ashesi.edu.gh / 1234'); 
});