CREATE DATABASE cafetaria_DBsystem;
USE cafetaria_DBsystem;


CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('student','staff','admin') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cafeteria VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    available BOOLEAN DEFAULT TRUE
);
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    cafeteria VARCHAR(50) NOT NULL,
    items TEXT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    status ENUM('pending','preparing','ready') DEFAULT 'pending',
    payment_method ENUM('meal_plan','cash','mobile_money') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE queues (
    cafeteria VARCHAR(50) PRIMARY KEY,
    current_queue INT DEFAULT 0,
    estimated_wait INT DEFAULT 10
);
CREATE TABLE feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cafeteria VARCHAR(50) NOT NULL,
    user_id INT,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO menu_items (cafeteria, name, price) VALUES
('Akorno', 'Jollof Rice with Chicken', 30.00),
('Akorno', 'Banku with Tilapia', 50.00),
('Akorno', 'Fried Rice', 15.00),
('Hallmark', 'Spaghetti Bolognese', 30.00),
('Hallmark', 'Grilled Chicken Salad', 28.00),
('Hallmark', 'Beef Burger', 30.00),
('Munchies', 'Chicken Wrap', 15.00),
('Munchies', 'Wakyye', 20.00),
('Munchies', 'Plain rice', 10.00);

INSERT INTO queues (cafeteria, current_queue, estimated_wait) VALUES
('Akorno', 5, 15),
('Hallmark', 3, 10),
('Munchies', 8, 20);