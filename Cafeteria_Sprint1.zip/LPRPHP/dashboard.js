var menus = {
    'Akorno': [
        {name: 'Jollof Rice', price: 25},
        {name: 'Banku & Fish', price: 30}
    ],
    'Hallmark': [
        {name: 'Spaghetti', price: 22},
        {name: 'Chicken Salad', price: 28}
    ],
    'Munchies': [
        {name: 'Chicken Wrap', price: 15},
        {name: 'Sandwich', price: 10}
    ]
};

var userOrder = [];
var currentCafe = '';
var staffCafe = '';
var queueNumber = 0;

// Switching the dashboard type, either user as Student and Faculty or cafeteria's staff:
function switchDashboard(type) {
    document.getElementById('user-dashboard').style.display = type === 'user' ? 'block' : 'none';
    document.getElementById('staff-dashboard').style.display = type === 'staff' ? 'block' : 'none';
    document.getElementById('dashboard-title').textContent = type + ' Dashboard';
}

// User accessibilities:
//1. Selecting the cafeteria they want:
function selectCafeteria(cafe) {
    currentCafe = cafe;
    document.getElementById('selected-cafe').textContent = cafe;
    showUserMenu(cafe);
    showQueue(cafe);
}

//2.Seeing the menu:
function showUserMenu(cafe) {
    var menuDiv = document.getElementById('menu-items');
    menuDiv.innerHTML = '';
    
    menus[cafe].forEach(function(item) {
        var itemDiv = document.createElement('div');
        itemDiv.innerHTML = item.name + ' - GHS ' + item.price + 
            ' <button onclick="addToOrder(\'' + item.name + '\',' + item.price + ')">Add</button>';
        menuDiv.appendChild(itemDiv);
    });
}

//  Add to order:
function addToOrder(name, price) {
    userOrder.push({name: name, price: price});
    showOrder();
}

// See their current order:
function showOrder() {
    var orderDiv = document.getElementById('order-items');
    orderDiv.innerHTML = '';
    
    var total = 0;
    userOrder.forEach(function(item, index) {
        var itemDiv = document.createElement('div');
        itemDiv.innerHTML = item.name + ' - GHS ' + item.price + 
            ' <button onclick="removeOrder(' + index + ')">Remove</button>';
        orderDiv.appendChild(itemDiv);
        total += item.price;
    });
    
    if (total > 0) {
        var totalDiv = document.createElement('div');
        totalDiv.innerHTML = 'Total: GHS ' + total;
        orderDiv.appendChild(totalDiv);
    }
}

// Remove the item from order:
function removeOrder(index) {
    userOrder.splice(index, 1);
    showOrder();
}

// Show payment fields based on selection:
function showPaymentFields() {
    var paymentMethod = document.getElementById('paymentMethod').value;
    
    document.getElementById('mealPlanFields').style.display = 'none';
    document.getElementById('mobileMoneyFields').style.display = 'none';
    document.getElementById('cashInfo').style.display = 'none';
    
    if (paymentMethod === 'meal_plan') {
        document.getElementById('mealPlanFields').style.display = 'block';
    } else if (paymentMethod === 'mobile_money') {
        document.getElementById('mobileMoneyFields').style.display = 'block';
    } else if (paymentMethod === 'cash') {
        document.getElementById('cashInfo').style.display = 'block';
    }
}

// Place order with tracking:
function placeOrderWithTracking() {
    if (userOrder.length === 0) {
        alert('Your order is empty');
        return;
    }
    
    var orderDate = document.getElementById('orderDate').value;
    var orderTime = document.getElementById('orderTime').value;
    var orderType = document.getElementById('orderType').value;
    var paymentMethod = document.getElementById('paymentMethod').value;
    
    if (!orderDate || !orderTime || !orderType || !paymentMethod) {
        alert('Please fill all fields');
        return;
    }
    
    // Payment validation:
    if (paymentMethod === 'meal_plan') {
        var studentId = document.getElementById('studentId').value;
        var mealPlanPassword = document.getElementById('mealPlanPassword').value;
        if (!studentId || !mealPlanPassword) {
            alert('Please enter Student ID and Password');
            return;
        }
    } else if (paymentMethod === 'mobile_money') {
        var phoneNumber = document.getElementById('phoneNumber').value;
        if (!phoneNumber) {
            alert('Please enter phone number');
            return;
        }
    }
    
    var total = userOrder.reduce(function(sum, item) { return sum + item.price; }, 0);
    var orderNumber = 'ORD' + Math.floor(1000 + Math.random() * 9000);
    
    var message = 'Order placed!\nOrder: ' + orderNumber + '\nTotal: GHS ' + total + 
                  '\nPayment: ' + paymentMethod + '\nDate: ' + orderDate + ' ' + orderTime;
    
    if (paymentMethod === 'mobile_money') {
        message += '\nPayment Code: MP' + Math.floor(1000 + Math.random() * 9000);
    } else if (paymentMethod === 'cash') {
        message += '\nPay when collecting order';
    }
    
    alert(message);
    
    // Show tracking:
    document.getElementById('queue-section').style.display = 'block';
    startOrderTracking(orderNumber);
    
    // Reset order@
    userOrder = [];
    showOrder();
}

// Start order tracking
function startOrderTracking(orderNumber) {
    document.getElementById('displayOrderNumber').textContent = orderNumber;
    
    var queuePosition = Math.floor(Math.random() * 5) + 1;
    document.getElementById('queuePosition').textContent = '#' + queuePosition;
    document.getElementById('ordersAhead').textContent = queuePosition - 1;
    document.getElementById('waitTime').textContent = (queuePosition * 5) + ' minutes';
    
    // Simple progress simulation
    var progress = 0;
    var interval = setInterval(function() {
        progress += 25;
        document.getElementById('queueProgress').style.width = progress + '%';
        
        if (progress >= 25) document.getElementById('step2').classList.add('active');
        if (progress >= 50) document.getElementById('step3').classList.add('active');
        if (progress >= 75) document.getElementById('step4').classList.add('active');
        
        if (progress >= 100) {
            clearInterval(interval);
            alert('Order ready for pickup!');
        }
    }, 3000);
}

// Reset order
function resetOrder() {
    userOrder = [];
    showOrder();
    document.getElementById('queue-section').style.display = 'none';
}

// Show queue
function showQueue(cafe) {
    var queueData = {Akorno: 5, Hallmark: 3, Munchies: 8};
    var waitTime = queueData[cafe] * 3;
    document.getElementById('queue-info').innerHTML = queueData[cafe] + ' people (' + waitTime + ' min)';
}

//  Submit feedback
function submitFeedback() {
    var feedback = document.getElementById('feedback').value;
    if (feedback) {
        alert('Thank you for your feedback!');
        document.getElementById('feedback').value = '';
    }
}

//Staff's accessibilities:
// Select cafeteria:
function staffSelectCafe(cafe) {
    staffCafe = cafe;
    document.getElementById('staff-cafe').textContent = cafe;
    showStaffMenu(cafe);
}

// Show menu for editing:
function showStaffMenu(cafe) {
    var menuDiv = document.getElementById('staff-menu');
    menuDiv.innerHTML = '';
    
    menus[cafe].forEach(function(item, index) {
        var itemDiv = document.createElement('div');
        itemDiv.innerHTML = item.name + ' - GHS ' + item.price + 
            ' <button onclick="removeItem(\'' + cafe + '\',' + index + ')">Remove</button>';
        menuDiv.appendChild(itemDiv);
    });
}

// Add menu item:
function addMenuItem() {
    var name = document.getElementById('new-item').value;
    var price = document.getElementById('new-price').value;
    
    if (!name || !price || !staffCafe) {
        alert('Please fill all fields');
        return;
    }
    
    if (!menus[staffCafe]) {
        menus[staffCafe] = [];
    }
    
    menus[staffCafe].push({name: name, price: parseFloat(price)});
    showStaffMenu(staffCafe);
    
    document.getElementById('new-item').value = '';
    document.getElementById('new-price').value = '';
}

// Removing items from menu: 
function removeItem(cafe, index) {
    menus[cafe].splice(index, 1);
    showStaffMenu(cafe);
}

// Changing the queue number:
function changeQueue(amount) {
    queueNumber = Math.max(0, queueNumber + amount);
    document.getElementById('queue-count').textContent = queueNumber;
}

//  Reset queue:
function resetQueue() {
    queueNumber = 0;
    document.getElementById('queue-count').textContent = queueNumber;
}

// Send notification:
function sendNotification() {
    var message = document.getElementById('notification').value;
    if (message) {
        alert('Notification sent!');
        document.getElementById('notification').value = '';
    }
}

// Logout
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = 'index.html';
    }
}

// Start with user dashboard
window.onload = function() {
    switchDashboard('user');
    
    // Set current date
    var today = new Date().toISOString().split('T')[0];
    var orderDateInput = document.getElementById('orderDate');
    if (orderDateInput) {
        orderDateInput.value = today;
    }
};