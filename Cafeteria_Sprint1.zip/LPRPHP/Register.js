// Simple form validation for register page
window.onload = function() {
    var registerForm = document.querySelector('.auth-form');
    
    registerForm.onsubmit = function(event) {
        var password = document.getElementById('password').value;
        var confirmPassword = document.getElementById('confirmPassword').value;
        var email = document.getElementById('email').value;
        var userType = document.getElementById('userType').value;
        
        // Checking if the passwords match: 
        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            event.preventDefault();
            return false;
        }
        
        // Checking the password length:
        if (password.length < 6) {
            alert('Password must be at least 6 characters long');
            event.preventDefault();
            return false;
        }
        
        // Checking if it is an Ashesi email:
        if (!email.includes('@ashesi.edu.gh')) {
            alert('Please use your Ashesi University email address');
            event.preventDefault();
            return false;
        }
        
        // Checking if the user type is selected:
        if (userType === '') {
            alert('Please select your account type');
            event.preventDefault();
            return false;
        }
        
        return true;
    };
};